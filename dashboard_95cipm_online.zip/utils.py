def gerar_dashboard(path):
    pass
